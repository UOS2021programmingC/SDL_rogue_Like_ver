// ----------------------------------------------------------------
// From Game Programming in C++ by Sanjay Madhav
// Copyright (C) 2017 Sanjay Madhav. All rights reserved.
//
// Released under the BSD License
// See LICENSE in root directory for full details.
// ----------------------------------------------------------------
// Updated by Chul 9&J teams
// in C_programing project in Mechanical Informaion Engineering UOS, 2021.
// ----------------------------------------------------------------

#pragma once
#include "SDL2/SDL.h"
#include <unordered_map>
#include <string>
#include <vector>
#include "Stage.h"

/**
 * @brief 전체적인 Game 진행을위한 구성요소 
 * GameLoop를 위한 기능들이 구성되어있다.
 * 게임의 루프와 인풋, 아웃풋등을 조절한다.
 */
class Game
{
public:
	Game();
	bool Initialize();
	void RunLoop();
	void Shutdown();

	//ADdd & Remove Compoonent
	void AddActor(class Actor* actor);
	void RemoveActor(class Actor* actor);

	void AddSprite(class SpriteComponent* sprite);
	void RemoveSprite(class SpriteComponent* sprite);

	//Add& Remove ACOTRs.
	void AddAsteroid(class Asteroid* ast);
	void RemoveAsteroid(class Asteroid* ast);
	std::vector<class Asteroid*>& GetAsteroids() { return mAsteroids; }

	//Get&Set Val
	class Ship* GetShip() {return mShip; }
	class Stage* GetStage() {return mStage; }
	float GetDiff() {return mDifficulty;}

	//SDL_Val
	SDL_Window* GetWindow() {return mWindow;}
	SDL_Renderer* GetRenderer() { return mRenderer;}
	SDL_Texture *GetTexture(const std::string &fileName);

	//PortalState
	void SetPortalState(bool value) { mActivePortal = value; }

	//적의 수
	int numEnemy;
	//stage변수
	Stage::STAGE mStageNUM;
	
private:
	void ProcessInput();
	void UpdateGame();
	void GenerateOutput();
	void LoadData();
	void UnloadData();
	
	// Map of textures loaded
	std::unordered_map<std::string, SDL_Texture*> mTextures;

	// All the actors in the game
	std::vector<class Actor*> mActors;
	// Any pending actors
	std::vector<class Actor*> mPendingActors;

	// All the sprite components drawn
	std::vector<class SpriteComponent*> mSprites;

	SDL_Window* mWindow;
	SDL_Renderer* mRenderer;
	Uint32 mTicksCount;
	bool mIsRunning;
	// Track if we're updating actors right now
	bool mUpdatingActors;

	// Game-specific
	class Ship *mShip; // Player's ship
	std::vector<class Asteroid*> mAsteroids;
	class Stage *mStage;

	//난도
	int mDifficulty;
	//포탈 활성 여부
	bool mActivePortal;
};
